package com.nurram.project.imagetextrecognition.util;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

public interface ClickUtil {
    void listClicked(View view, String words, ImageView play);
}
